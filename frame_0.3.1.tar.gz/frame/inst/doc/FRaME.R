## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(frame)
library(dplyr)
library(extraDistr)
library(kableExtra)
library(rmarkdown)

## ----params_input-------------------------------------------------------------
record <- 1
data(Site)
data(Structure)
data(Flora)
data(Traits)
input <- paramBuilder(Site, Structure, Flora, Traits, record)



## ----ffm_run, eval = FALSE, results= 'hide'-----------------------------------
#  ffm_run(input, db.path = "out.db", db.recreate = TRUE)

## ----db_load------------------------------------------------------------------
results<-ffm_db_load("out.db")

## ----flamesummaries-----------------------------------------------------------
results$FlameSummaries %>%
 kbl() %>% 
  kable_material(c("striped", "hover"))

## ----ignitionpaths------------------------------------------------------------
results$IgnitionPaths %>% 
  paged_table()

## ----ros----------------------------------------------------------------------
results$ROS %>% 
  kbl() %>% 
  kable_material(c("striped", "hover"))

## ----runs---------------------------------------------------------------------
results$Runs %>% 
  kbl() %>% 
  kable_material(c("striped", "hover"))

## ----sites--------------------------------------------------------------------
results$Sites%>% 
  kbl() %>% 
  kable_material(c("striped", "hover"))

## ----strata-------------------------------------------------------------------
results$Strata%>% 
  kbl() %>% 
  kable_material(c("striped", "hover"))

## ----surfaceresults-----------------------------------------------------------

results$SurfaceResults %>% 
  kbl() %>% 
  kable_material(c("striped", "hover"))


